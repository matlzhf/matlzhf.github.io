clc
clear
close all

%%
load('brain_T1w_noise_15');
exact = I;
noisy = f;
alpha=0.015;  beta = 0.08;     gamma = 1;  

%%
opts = struct('alpha',alpha,'beta',beta,'gamma',gamma,...
    'sigma',sigma,'exact',exact,...
    'maxiter',500,'tol',1e-4,'record_flag',0);
tic
out = TVRicianNew(noisy,opts);
toc


%%
uclean = out.u;

[BW,maskedImage] = segmentImage(exact);
psnr_u_BW = psnr(uint8(uclean.*BW),uint8(exact.*BW));
ssim_u_BW = ssim(uint8(uclean.*BW),uint8(exact.*BW));


figure(1);clf;
subplot(2,2,1);
imagesc(exact);
colormap(gray);
title('Original');

subplot(2,2,2);
imagesc(noisy);
colormap(gray);
title(['noisy PSNR:' num2str(psnr(exact,noisy,255),'%.2f')]);

subplot(2,2,3);
imagesc(uclean);
colormap(gray);
title(['denoised PSNR: ' num2str(psnr_u_BW,'%.2f') ' SSIM: ' num2str(ssim_u_BW,'%.4f')]);

subplot(2,2,4);
imagesc(noisy-uclean);
colormap(gray);
title('difference');

%%
real_iter = length(out.relerr);
figure(2); clf;
subplot(2,2,1);
relerr = out.relerr;
semilogy(1:real_iter,relerr,'m','linewidth',1.5)
title('Rel\_Err u','FontWeight','normal','FontSize',11);
xlabel('iter');

subplot(2,2,2);
residual = out.residual;
semilogy(1:real_iter,residual(1:end),'b','linewidth',1.5);
title('Residual','FontWeight','normal','FontSize',11);
xlabel('iter');

subplot(2,2,3);
psnr_u = out.psnr_u;
plot(1:real_iter,psnr_u,'-','linewidth',1.0);
title('PSNR','FontWeight','normal','FontSize',11);
xlabel('iter');


