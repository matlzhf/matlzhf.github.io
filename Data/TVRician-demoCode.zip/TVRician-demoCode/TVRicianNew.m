function outputs = TVRicianNew(f,opts)
%%
alpha = opts.alpha;
beta = opts.beta;
gamma = opts.gamma;
sigma = opts.sigma;
maxiter = opts.maxiter;
tol = opts.tol;
record_flag = opts.record_flag;
u_true = opts.exact;
%---------------------------------------
[d1,d2] = size(f);
lambda_1 = zeros(d1,d2);
lambda_2 = zeros(d1,d2);
u = sqrt(max(f.^2 - 2*sigma^2,0));
g = sqrt(max(f.^2 - 2*sigma^2,0));
rng('default')
rng(2020)
n1 = 0*randn(d1,d2);
rng(2021)
n2 = sigma*randn(d1,d2);
% n2 = sqrt((f.^2 - u.^2));

%---------------------------------------
options.order = 1; options.bound = 'sym';
dt = 1/4;
P1 = zeros([d1,d2]);
P2 = zeros([d1,d2]);
%---------------------------------------
for iter =1:maxiter 
    %----------------------v-subproblem------------------------------------
	w1 = u + n1 + lambda_1;
	w2 = n2 + lambda_2;
	w = sqrt(w1.^2 + w2.^2);
	rhow = f./(max(w,1e-6));
	v1 = rhow.*w1;
	v2 = rhow.*w2;
    %----------------------u-subproblem------------------------------------
	uk = u;
	w = v1 - n1 - lambda_1;  
    w = (beta*g + gamma*w)/(beta + gamma);
    %%---------------------------
    % Chambolle Projection Method
    %%---------------------------
    k = 0;
    while k < 2
        Q = div(P1,P2,options) - (gamma + beta)*w;
        [Q1,Q2] = grad(Q,options);
        Qnorm = sqrt(Q1.^2 + Q2.^2);
        WP = 1./(1 + dt*Qnorm);
        P1 = (P1 + dt*Q1).*WP;
        P2 = (P2 + dt*Q2).*WP;
        k = k + 1;
    end
    u = w - div(P1,P2)/(gamma + beta);

    %----------------------n-subproblem------------------------------------
	w1 = v1 - u - lambda_1;
	w2 = v2 - lambda_2;
	n1 = gamma/(gamma + alpha)*w1;
	n2 = gamma/(gamma + alpha)*w2;

    %----------------------lam-update--------------------------------------
	lambda_1 = lambda_1 + u + n1 - v1;
	lambda_2 = lambda_2 + n2 - v2;
	%------------diagnostics, reporting, termination checks----------------
	diff_u = u - uk;
	relerr = sqrt(sum(diff_u(:).^2))/sqrt(sum(uk(:).^2));
	residual1 = v1 - u - n1;
	residual2 = v2 - n2;
	residual = sum(abs(residual1(:))) + sum(abs(residual2(:)));
	residual = residual/(d1*d2);
    psnr_u= psnr(uint8(u), uint8(u_true),255);
%     fprintf('The iteration number is: %4d  relerr: %.4e residual: %.4e psnr: %.4e\n',iter, relerr, residual,psnr_u);
	outputs.residual(iter) = residual;
	outputs.relerr(iter) = relerr;
    outputs.psnr_u(iter) = psnr_u;
    
	outputs.energy(iter) = RicianEnergy(u, g, n1, n2, alpha, beta);
	if (relerr < tol)
		if (record_flag == 1)
			continue
		end
		break
	end 
end
outputs.u = u;
outputs.g = g;
outputs.n1 = n1;
outputs.n2 = n2;
outputs.iter = iter;
end

function energy = RicianEnergy(u, g, n1, n2, alpha, beta)
options.order = 1; options.bound = 'sym';
[grad_x,grad_y] = grad(u,options);
modGrad = sqrt(grad_x.^2 + grad_y.^2);

fidelity = alpha/2*(n1.^2 + n2.^2) + beta/2 *(u - g).^2;

intGrad = sum(modGrad(:));
intFid = sum(fidelity(:));

energy = intGrad + intFid;
end
